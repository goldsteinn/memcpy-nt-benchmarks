#! /bin/bash

python3 runall.py memset memset-results-spr.txt > memset-logs 2>1
python3 runall.py memcpy memcpy-results-spr.txt > memcpy-logs 2>1
cat /proc/cpuinfo > spr.txt
